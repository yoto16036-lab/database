#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <memory>
#include <chrono>
#include <unordered_map>
#include <iomanip>

struct Vector3 {
    double x;
    double y;
    double z;

    Vector3(double px = 0.0, double py = 0.0, double pz = 0.0) : x(px), y(py), z(pz) {}

    Vector3 operator+(const Vector3& o) const { return {x + o.x, y + o.y, z + o.z}; }
    Vector3 operator-(const Vector3& o) const { return {x - o.x, y - o.y, z - o.z}; }
    Vector3 operator*(double scalar) const { return {x * scalar, y * scalar, z * scalar}; }

    double distanceTo(const Vector3& o) const {
        double dx = x - o.x;
        double dy = y - o.y;
        double dz = z - o.z;
        return std::sqrt(dx * dx + dy * dy + dz * dz);
    }

    double length() const {
        return std::sqrt(x * x + y * y + z * z);
    }

    Vector3 normalize() const {
        double len = length();
        if (len == 0.0) return {0.0, 0.0, 0.0};
        return {x / len, y / len, z / len};
    }

    void print() const {
        std::cout << "(" << std::fixed << std::setprecision(2) 
                  << x << ", " << y << ", " << z << ")";
    }
};

enum class EntityType {
    PLAYER,
    BOT,
    MOB,
    UNKNOWN
};

enum class ThreatLevel {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
};

struct TargetingConfig {
    double maxScanDistance = 64.0;
    double fieldOfViewDegrees = 120.0;
    bool requireLineOfSight = true;
    bool prioritizeLowHealth = true;
};

class Entity {
private:
    int id;
    std::string name;
    EntityType type;
    Vector3 position;
    Vector3 velocity;
    double health;
    double maxHealth;
    bool isTeamEnemy;
    bool active;

public:
    Entity(int id, std::string name, EntityType type, Vector3 pos, bool enemy)
        : id(id), name(name), type(type), position(pos), velocity(0, 0, 0),
          health(100.0), maxHealth(100.0), isTeamEnemy(enemy), active(true) {}

    int getId() const { return id; }
    std::string getName() const { return name; }
    EntityType getType() const { return type; }
    Vector3 getPosition() const { return position; }
    void setPosition(const Vector3& pos) { position = pos; }
    
    Vector3 getVelocity() const { return velocity; }
    void setVelocity(const Vector3& vel) { velocity = vel; }

    double getHealth() const { return health; }
    void setHealth(double h) { health = std::max(0.0, std::min(h, maxHealth)); }

    bool isEnemy() const { return isTeamEnemy; }
    void setEnemy(bool enemy) { isTeamEnemy = enemy; }

    bool isActive() const { return active; }
    void setActive(bool act) { active = act; }

    bool isBot() const { return type == EntityType::BOT; }

    void update(double deltaTime) {
        position = position + (velocity * deltaTime);
    }
};

class BotEngineManager {
private:
    std::unordered_map<int, std::shared_ptr<Entity>> entities;
    TargetingConfig config;
    Vector3 localPlayerPosition;
    Vector3 localPlayerLookVector;

    bool checkLineOfSight(const Vector3& origin, const Vector3& target) {
        double dist = origin.distanceTo(target);
        if (dist > config.maxScanDistance) return false;
        return true; 
    }

    double calculateThreatScore(const Entity& observer, const Entity& candidate, double distance) {
        double score = 0.0;

        double distanceWeight = std::max(0.0, 1.0 - (distance / config.maxScanDistance));
        score += distanceWeight * 50.0;

        if (config.prioritizeLowHealth) {
            double healthPercent = candidate.getHealth() / 100.0;
            double healthWeight = 1.0 - healthPercent;
            score += healthWeight * 30.0;
        }

        if (candidate.isBot()) {
            score += 20.0;
        }

        return score;
    }

public:
    BotEngineManager() : localPlayerPosition(0, 0, 0), localPlayerLookVector(0, 0, 1) {}

    void setConfig(const TargetingConfig& newConfig) {
        config = newConfig;
    }

    void setLocalPlayerState(const Vector3& pos, const Vector3& lookDir) {
        localPlayerPosition = pos;
        localPlayerLookVector = lookDir.normalize();
    }

    void addEntity(std::shared_ptr<Entity> entity) {
        if (entity) {
            entities[entity->getId()] = entity;
        }
    }

    void removeEntity(int id) {
        entities.erase(id);
    }

    void updateAll(double deltaTime) {
        for (auto& pair : entities) {
            pair.second->update(deltaTime);
        }
    }

    std::shared_ptr<Entity> findEnemyBot() {
        std::shared_ptr<Entity> bestTarget = nullptr;
        double highestScore = -1.0;

        for (const auto& pair : entities) {
            const auto& entity = pair.second;

            if (!entity->isActive()) continue;
            if (!entity->isEnemy()) continue;
            if (!entity->isBot()) continue;

            Vector3 targetPos = entity->getPosition();
            double distance = localPlayerPosition.distanceTo(targetPos);

            if (distance > config.maxScanDistance) {
                continue;
            }

            Vector3 directionToTarget = (targetPos - localPlayerPosition).normalize();
            double dotProduct = localPlayerLookVector.x * directionToTarget.x +
                                localPlayerLookVector.y * directionToTarget.y +
                                localPlayerLookVector.z * directionToTarget.z;
            
            double halfFovRad = (config.fieldOfViewDegrees / 2.0) * (3.14159265358979323846 / 180.0);
            double fovThreshold = std::cos(halfFovRad);

            if (dotProduct < fovThreshold) {
                continue;
            }

            if (config.requireLineOfSight) {
                if (!checkLineOfSight(localPlayerPosition, targetPos)) {
                    continue;
                }
            }

            double score = calculateThreatScore(Entity(0, "", EntityType::UNKNOWN, localPlayerPosition, false), *entity, distance);

            if (score > highestScore) {
                highestScore = score;
                bestTarget = entity;
            }
        }

        return bestTarget;
    }

    void printEntityList() const {
        std::cout << "\n=== ACTIVE ENTITY REGISTRY ===" << std::endl;
        for (const auto& pair : entities) {
            const auto& e = pair.second;
            std::cout << "[ID: " << e->getId() << "] " 
                      << e->getName() << " | Type: " 
                      << (e->isBot() ? "BOT" : "PLAYER")
                      << " | Enemy: " << (e->isEnemy() ? "YES" : "NO")
                      << " | Pos: ";
            e->getPosition().print();
            std::cout << " | HP: " << e->getHealth() << std::endl;
        }
        std::cout << "==============================\n" << std::endl;
    }
};

int main() {
    std::cout << "[*] Initializing Atlas Bot Engine Module..." << std::endl;

    BotEngineManager engine;

    TargetingConfig config;
    config.maxScanDistance = 50.0;
    config.fieldOfViewDegrees = 140.0;
    config.requireLineOfSight = true;
    config.prioritizeLowHealth = true;
    engine.setConfig(config);

    engine.setLocalPlayerState(Vector3(0.0, 0.0, 0.0), Vector3(0.0, 0.0, 1.0));

    engine.addEntity(std::make_shared<Entity>(1, "FriendlyMate", EntityType::PLAYER, Vector3(5.0, 0.0, 10.0), false));
    engine.addEntity(std::make_shared<Entity>(2, "AtlasBot_Alpha", EntityType::BOT, Vector3(12.0, 0.0, 25.0), true));
    
    auto woundedBot = std::make_shared<Entity>(3, "AtlasBot_Beta", EntityType::BOT, Vector3(-8.0, 0.0, 15.0), true);
    woundedBot->setHealth(35.0);
    engine.addEntity(woundedBot);

    engine.addEntity(std::make_shared<Entity>(4, "NeutralObserver", EntityType::MOB, Vector3(2.0, 0.0, 5.0), false));
    engine.addEntity(std::make_shared<Entity>(5, "AtlasBot_Gamma", EntityType::BOT, Vector3(30.0, 0.0, 60.0), true));

    engine.printEntityList();

    std::cout << "[*] Executing findEnemyBot() scan..." << std::endl;
    std::shared_ptr<Entity> target = engine.findEnemyBot();

    if (target) {
        std::cout << "\n[+] TARGET ACQUIRED!" << std::endl;
        std::cout << "    Name:   " << target->getName() << std::endl;
        std::cout << "    ID:     " << target->getId() << std::endl;
        std::cout << "    Health: " << target->getHealth() << "/100.0" << std::endl;
        std::cout << "    Coords: ";
        target->getPosition().print();
        std::cout << std::endl;
    } else {
        std::cout << "\n[-] No enemy bots found within targeting parameters." << std::endl;
    }

    return 0;
}
